/**
 * Chat module — launch CLI coding agents with Azure Functions startup prompt.
 *
 * CLI usage: azure-functions-skills chat [--agent <name>] [--prompt <text>] [--dir <path>]
 * Library:   import { chat, buildStartupPrompt, LAUNCHERS } from '@azure/functions-skills/chat'
 */
import type { ChatOptions, ChatResult, DetectedCliAgent, Launcher, LauncherId } from '../types.js';
type ResolvedLauncherCommand = {
    command: string;
    argsPrefix: string[];
    shell: boolean;
};
type ResolveLauncherOptions = {
    platform?: NodeJS.Platform;
    env?: NodeJS.ProcessEnv;
};
type StartupPromptOptions = {
    setupSkillPending?: boolean;
    setupCompleteCommand?: string;
};
export declare const LAUNCHERS: Record<LauncherId, Launcher>;
/**
 * Detect which CLI coding agents are installed.
 * @returns {Promise<Array<{id: string, command: string, description: string}>>}
 */
export declare function detectCliAgents(): Promise<DetectedCliAgent[]>;
/**
 * Build the startup prompt from template + project context.
 * @param {string} dir - Project directory to analyze
 * @returns {Promise<string>}
 */
export declare function buildStartupPrompt(dir: string, options?: StartupPromptOptions): Promise<string>;
/**
 * Launch a CLI coding agent with Azure Functions startup prompt.
 *
 * @param {object} options
 * @param {string} [options.agent] - Agent ID (github-copilot, claude-code, codex)
 * @param {string} [options.prompt] - Custom prompt (overrides startup template)
 * @param {string} [options.dir] - Working directory
 * @returns {Promise<{childProcess: object | null, agent: string, prompt: string}>}
 */
export declare function chat(options?: ChatOptions): Promise<ChatResult>;
export declare function resolveLauncherCommand(command: string, options?: ResolveLauncherOptions): ResolvedLauncherCommand;
export {};
