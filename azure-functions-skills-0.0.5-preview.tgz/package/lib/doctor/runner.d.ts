/**
 * DoctorRunner — execute checks, aggregate results, produce report.
 */
import type { DoctorOptions, DoctorReport } from './types.js';
export interface RunResult {
    report: DoctorReport;
    exitCode: number;
}
export declare function runDoctor(options: DoctorOptions): Promise<RunResult>;
/**
 * Detect whether doctor is being invoked on a contributor pull request context.
 *
 * --deep spawns an LLM agent with file-write and shell-execution permissions.
 * Running it on workspace files from an untrusted PR is equivalent to giving
 * that PR shell access to the runner: prompt injection in the PR's source
 * code can hijack the agent into exfiltrating secrets, modifying files, or
 * running arbitrary commands. We therefore refuse --deep when a PR-like
 * context is detected.
 *
 * Heuristics across GitHub Actions, Azure DevOps, and GitLab CI:
 *   - GitHub Actions: GITHUB_EVENT_NAME=pull_request or pull_request_target
 *   - Azure DevOps: BUILD_REASON=PullRequest
 *   - GitLab CI: CI_PIPELINE_SOURCE=merge_request_event
 *
 * Override: AZURE_FUNCTIONS_DOCTOR_TRUST_PR=1 explicitly opts in (for
 * mirror or trusted-environment workflows that need to scan PRs).
 */
export declare function isContributorPrContext(): boolean;
/**
 * Build the warning shown when plugin install fails and we fall back to local install.
 * Must remain pure ASCII so it does not mojibake on Windows PowerShell stderr (cp932/cp1252).
 */
export declare function buildPluginFallbackWarning(errMessage: string): string;
