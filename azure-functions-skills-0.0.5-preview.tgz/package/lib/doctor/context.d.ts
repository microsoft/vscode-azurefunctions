import type { ProjectContext } from './types.js';
export declare function loadProjectContext(dir: string): Promise<ProjectContext>;
