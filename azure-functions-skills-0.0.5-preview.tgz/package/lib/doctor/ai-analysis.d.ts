import type { CheckSeverity, DoctorCheckResult, DoctorReport } from './types.js';
export declare function buildDoctorPrompt(tier1Results: DoctorCheckResult[], reportPath: string): string;
export interface AgentCommand {
    command: string;
    args: string[];
}
export declare function buildAgentCommand(agent: string, prompt: string, _reportPath: string): AgentCommand;
/**
 * Build the warning text shown before invoking an agent in deep mode.
 *
 * The agent runs with elevated permissions (file write, shell access, all-tools).
 * Users running doctor on an untrusted workspace can be subjected to prompt
 * injection that modifies files or executes commands beyond the validation scope.
 * This warning informs the user before the agent is spawned.
 */
export declare function buildDeepWarning(agent: string): string;
export interface AiAnalysisResult {
    findings: DoctorCheckResult[];
    durationMs: number;
    error?: string;
    agentOutput?: string;
}
export declare function runAiAnalysis(agent: string, prompt: string, reportPath: string, dir: string, timeoutMs: number): Promise<AiAnalysisResult>;
export declare function readAiReport(reportPath: string): Promise<DoctorCheckResult[]>;
export declare function mergeReports(report: DoctorReport, aiFindings: DoctorCheckResult[], agent: string, durationMs: number, error?: string, severityThreshold?: CheckSeverity): DoctorReport;
