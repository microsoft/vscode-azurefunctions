/**
 * Version rules for Tier 1 checks — hardcoded fallback.
 * Used only when the Stacks API (stacks.ts) is unreachable and no cache exists.
 * Keep in sync with https://functions-next.azure.com/stacks/functionAppStacks/?api-version=2023-01-01
 * Last synced: 2026-05-26
 */
export declare const SUPPORTED_RUNTIME_VERSIONS: string[];
export declare const RECOMMENDED_EXTENSION_BUNDLE: {
    id: string;
    minVersion: string;
    maxVersion: string;
};
export declare const SUPPORTED_NODE_VERSIONS: number[];
export declare const SUPPORTED_PYTHON_VERSIONS: string[];
export declare const SUPPORTED_DOTNET_VERSIONS: string[];
/** Settings that are deprecated and should be replaced. */
export declare const DEPRECATED_SETTINGS: Record<string, string>;
