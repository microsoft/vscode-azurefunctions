/**
 * Report formatters for doctor output.
 */
import type { DoctorReport, OutputFormat } from './types.js';
export declare function formatReport(report: DoctorReport, format: OutputFormat): string;
