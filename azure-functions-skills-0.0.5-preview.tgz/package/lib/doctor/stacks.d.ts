import type { LanguageStackInfo, StackVersionInfo, StacksResolverOptions } from './stacks-types.js';
export type VersionStatusKind = 'supported' | 'eol-soon' | 'eol' | 'deprecated' | 'preview' | 'unknown';
export interface VersionStatus {
    status: VersionStatusKind;
    version: string;
    isDefault: boolean;
    endOfLifeDate: string | null;
    message: string;
}
export declare function parseStacksResponse(raw: unknown): LanguageStackInfo[];
export declare function getLanguageVersions(stacks: LanguageStackInfo[], language: string): StackVersionInfo[];
export declare function checkVersionStatus(stacks: LanguageStackInfo[], language: string, version: string): VersionStatus;
export type StacksSourceFn = (options: {
    apiVersion: string;
    timeoutMs: number;
}) => Promise<unknown>;
export declare function fetchStacksWithAzureCli(options: {
    apiVersion: string;
    timeoutMs: number;
}): Promise<unknown>;
export declare function resolveStacks(options: StacksResolverOptions, sourceFn?: StacksSourceFn): Promise<LanguageStackInfo[]>;
