export interface CopilotCliCommandOptions {
    yolo?: boolean;
    agent?: string;
}
export interface AgentRunMetadata {
    agent: string;
    prompt: string;
    command: string[];
    startedAt: string;
}
export declare function buildCopilotCliCommand(prompt: string, options?: CopilotCliCommandOptions): string[];
export declare function createAgentRunMetadata(prompt: string, options?: CopilotCliCommandOptions): AgentRunMetadata;
