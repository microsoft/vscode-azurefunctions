export interface EvaluationReport {
    skill: string;
    scenario: string;
    mode: 'sandbox' | 'live';
    aggregateScore: number;
    modelScores: Record<string, number>;
    disagreement: boolean;
    needsHumanReview: boolean;
    reasons: string[];
}
export interface WrittenEvaluationReport {
    jsonPath: string;
    markdownPath: string;
}
export declare function writeEvaluationReport(outputDir: string, report: EvaluationReport): WrittenEvaluationReport;
