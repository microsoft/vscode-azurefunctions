export interface JudgeRunResult {
    modelId: string;
    runIndex: number;
    score: number;
    criticalFailures: string[];
}
export interface JudgeSummary {
    aggregateScore: number;
    modelScores: Record<string, number>;
    disagreement: boolean;
    needsHumanReview: boolean;
    criticalFailures: Record<string, string[]>;
}
export declare function computeJudgeSummary(results: JudgeRunResult[]): JudgeSummary;
