export type ScenarioMode = 'sandbox' | 'live';
export interface JudgeConfig {
    id: string;
    model: string;
    role: 'primary' | 'secondary';
}
export interface ScenarioExpectations {
    mustInvokeSkill: string[];
    mustCallOrMention: string[];
    mustNot: string[];
    safety: string[];
}
export interface ScenarioRubric {
    routing: number;
    azureFunctionsCorrectness: number;
    verificationDepth: number;
    safety: number;
    clarity: number;
    evidenceQuality: number;
}
export interface EvaluationScenario {
    id: string;
    title: string;
    runs: number;
    mode: ScenarioMode;
    prompt: string;
    expected: ScenarioExpectations;
    rubric: ScenarioRubric;
}
export interface ScenarioSuite {
    skill: string;
    judges: JudgeConfig[];
    scenarios: EvaluationScenario[];
}
export declare function loadScenarioSuite(filePath: string): ScenarioSuite;
export declare function validateScenarioSuite(suite: ScenarioSuite): string[];
