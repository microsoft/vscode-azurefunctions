export interface FakeToolScriptsResult {
    binDir: string;
    toolPaths: string[];
}
export declare function createFakeToolScripts(binDir: string, tools: string[]): FakeToolScriptsResult;
