/**
 * Setup module — detects coding agents and applies Azure Functions skill files.
 * Usable as CLI (`npx @azure/functions-skills setup`) or library (VS Code extension).
 */
import type { CliAgentName, SetupOptions, SetupResult } from '../types.js';
/**
 * Detect which coding agents are available in the environment.
 * Returns an array of agent identifiers: 'ghcp', 'claude', 'codex'.
 */
export declare function detectAgents(): Promise<CliAgentName[]>;
/**
 * Apply Azure Functions skill setup to a target directory.
 *
 * @param {string} targetDir - Directory to write files to
 * @param {object} options
 * @param {string[]} options.agents - Agent identifiers to set up for
 * @returns {object} Summary with agents, filesWritten, welcomeMessage
 */
export declare function applySetup(targetDir: string, options?: SetupOptions): Promise<SetupResult>;
export { installLocalSkills, type GitRepoResult, type GitRepoResultStatus, type LocalInstallOptions, type LocalInstallResult, } from './local-install.js';
export { checkPackageUpdate, type PackageUpdateInfo, type PackageUpdateOptions, type PackageUpdateStatus, } from './package-update.js';
