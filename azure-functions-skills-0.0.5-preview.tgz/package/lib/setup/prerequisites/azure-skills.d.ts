import type { PrerequisiteProvider } from './types.js';
export declare const azureSkillsManualCommands: string[];
export declare const azureSkillsProvider: PrerequisiteProvider;
