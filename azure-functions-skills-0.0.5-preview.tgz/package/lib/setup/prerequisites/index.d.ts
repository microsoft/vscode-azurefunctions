import type { EnsurePrerequisitesOptions, PrerequisiteResult } from './types.js';
export declare function ensurePrerequisites(options: EnsurePrerequisitesOptions): Promise<PrerequisiteResult[]>;
export type { CommandResult, CommandRunner, EnsurePrerequisitesOptions, PrerequisiteContext, PrerequisiteMode, PrerequisiteProvider, PrerequisiteResult, PrerequisiteStatus, } from './types.js';
