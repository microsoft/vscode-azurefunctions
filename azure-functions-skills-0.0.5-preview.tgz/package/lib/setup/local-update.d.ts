/**
 * Local update module — updates a locally-installed workspace with file-type-aware strategies.
 *
 * Unlike `applySetup()` which overwrites everything via cpSync, this module:
 * - Overwrites managed content (skills, agent definitions, hooks)
 * - Uses managed-block replacement for routing files (preserves user customizations)
 * - Deep-merges JSON settings files and saves aside non-JSON settings files for manual merge
 * - Supports --force to overwrite everything
 */
import type { CliAgentName, FilePrompter } from '../types.js';
export type { FilePrompter, FilePromptResult } from '../types.js';
export interface LocalUpdateOptions {
    agents: CliAgentName[];
    force?: boolean;
    dryRun?: boolean;
    yes?: boolean;
    /** When provided, called for each save-aside candidate to let user choose. */
    prompter?: FilePrompter;
}
export interface LocalUpdateResult {
    agents: CliAgentName[];
    overwritten: string[];
    managedBlockUpdated: string[];
    savedAside: Array<{
        original: string;
        aside: string;
    }>;
    dryRun: boolean;
}
/**
 * Apply a local update to a workspace, using file-type-aware strategies.
 */
export declare function applyLocalUpdate(targetDir: string, options: LocalUpdateOptions): Promise<LocalUpdateResult>;
/**
 * Generate the save-aside path for a file, preserving the original extension.
 * Example: `CLAUDE.md` → `CLAUDE.azure-functions-skills-new.md`
 */
export declare function saveAsidePath(filePath: string): string;
/**
 * Create an interactive prompter that asks the user via readline.
 * Shows file path and offers: overwrite / skip / diff.
 */
export declare function createInteractivePrompter(): FilePrompter;
