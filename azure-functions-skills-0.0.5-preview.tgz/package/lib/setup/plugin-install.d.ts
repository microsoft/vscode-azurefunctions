/**
 * Plugin install module — register plugins natively with each platform.
 *
 * Instead of copying files, this registers the plugin at its npm package location,
 * so the platform manages updates and lifecycle.
 */
import type { BuildTargetName, FilePrompter } from '../types.js';
import type { CommandRunner } from './prerequisites/types.js';
interface PluginInstallResult {
    target: BuildTargetName;
    method: string;
    path: string;
    instructions: string;
}
interface CodexMarketplacePlugin {
    name: string;
    [key: string]: unknown;
}
interface CodexMarketplace {
    plugins?: CodexMarketplacePlugin[];
    [key: string]: unknown;
}
export type PluginOperationAction = 'install' | 'update';
export type PluginOperationScope = 'workspace' | 'user';
export type PluginOperationSource = 'marketplace' | 'local' | 'github';
export interface PluginOperationOptions {
    action: PluginOperationAction;
    agents: BuildTargetName[];
    projectDir: string;
    dryRun?: boolean;
    scope?: PluginOperationScope;
    source?: PluginOperationSource;
    version?: string;
    workspace?: boolean;
    runner?: CommandRunner;
    platform?: NodeJS.Platform;
    yes?: boolean;
    force?: boolean;
    prompter?: FilePrompter;
    passthroughArgs?: string[];
}
export interface PluginOperationStep {
    target: BuildTargetName;
    kind: 'plugin-registration' | 'workspace-activation';
    description: string;
    commands?: string[];
    path?: string;
}
export interface PluginOperationResult {
    action: PluginOperationAction;
    agents: BuildTargetName[];
    dryRun: boolean;
    scope: PluginOperationScope;
    source: PluginOperationSource;
    version: string;
    steps: PluginOperationStep[];
    filesWritten: number;
}
/**
 * Get the absolute path to a built plugin directory within this package.
 * @param {'ghcp' | 'claude' | 'codex'} target
 * @returns {string}
 */
export declare function getPluginDir(_target: BuildTargetName): string;
/**
 * Generate VS Code settings entries to register the GHCP plugin.
 * @param {string} pluginPath - Absolute path to the plugin directory
 * @returns {object} Settings to merge into .vscode/settings.json
 */
export declare function generateVscodeSettings(pluginPath: string): Record<string, unknown>;
/**
 * Generate a Codex marketplace entry pointing to the plugin.
 * @param {string} pluginPath - Absolute path to the plugin directory
 * @returns {object} Marketplace JSON
 */
export declare function generateCodexMarketplaceEntry(pluginPath: string): CodexMarketplace;
/**
 * Generate Claude settings additions for plugin registration.
 * Uses --add-dir equivalent in settings to point to plugin skills directory.
 * @param {string} pluginPath - Absolute path to the Claude plugin directory
 * @returns {object} Settings to merge
 */
export declare function generateClaudeSettings(pluginPath: string): Record<string, unknown>;
/**
 * Install plugin natively for a given platform.
 * @param {'ghcp' | 'claude' | 'codex'} target
 * @param {string} projectDir - The project directory
 * @returns {{target: string, method: string, path: string, instructions: string}}
 */
export declare function installPlugin(target: BuildTargetName, projectDir: string): PluginInstallResult;
export declare function planPluginOperation(options: PluginOperationOptions): PluginOperationResult;
export declare function runPluginOperation(options: PluginOperationOptions): Promise<PluginOperationResult>;
export {};
