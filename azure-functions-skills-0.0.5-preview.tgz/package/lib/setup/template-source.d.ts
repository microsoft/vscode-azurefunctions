import type { TemplateSourceOptions, TemplateSourceResult } from '../types.js';
export declare function resolveTemplateSource(options?: TemplateSourceOptions): TemplateSourceResult;
export declare function cleanupTemplateSource(source: TemplateSourceResult): void;
export declare function loadBuildDataFromTemplates(templatesDir: string): {
    skillsDir: string;
    mcpServersPath: string;
    agentsDir: string;
    hooksDir: string;
};
export declare function isValidWorkspaceDir(workspaceDir: string): boolean;
