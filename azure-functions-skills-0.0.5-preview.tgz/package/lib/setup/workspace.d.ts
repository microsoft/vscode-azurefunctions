import type { WorkspaceApplyOptions, WorkspaceApplyResult } from '../types.js';
export declare function applyWorkspace(targetDir: string, options?: WorkspaceApplyOptions): Promise<WorkspaceApplyResult>;
