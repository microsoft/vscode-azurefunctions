import type { BuildTargetName, LauncherId, PluginInstallMode } from '../types.js';
export declare const STATE_DIR_NAME = ".azure-functions-skills";
export declare const STATE_FILE_NAME = "state.local.json";
export declare const STATE_IGNORE_ENTRY = ".azure-functions-skills/state.local.json";
export type StateSetupStatus = 'not-run' | 'prompted' | 'completed';
export type StateInstallAction = 'install' | 'update';
export interface AgentState {
    installed: boolean;
    launcherId: LauncherId;
    installMode?: PluginInstallMode;
    lastInstalledAt?: string | null;
    lastUpdatedAt?: string | null;
    workspaceActivation?: {
        mcp: boolean;
        hooks: boolean;
        agentDefinition: boolean;
    };
}
export interface AzureFunctionsSkillsState {
    schemaVersion: 1;
    package: {
        name: string;
        version: string;
    };
    workspace: {
        root: string;
        stateFile: string;
        createdAt: string;
        updatedAt: string;
    };
    install: {
        mode: PluginInstallMode;
        source: string;
        scope: string;
        lastAction: StateInstallAction;
        lastRunAt: string;
    };
    agents: Record<BuildTargetName, AgentState>;
    chat: {
        defaultAgent: LauncherId | null;
        lastAgent: LauncherId | null;
        lastStartedAt: string | null;
    };
    setupSkill: {
        status: StateSetupStatus;
        promptedAt: string | null;
        completedAt: string | null;
        completedBy: LauncherId | null;
    };
}
export interface RecordInstallStateOptions {
    action: StateInstallAction;
    agents: BuildTargetName[];
    mode: PluginInstallMode;
    source: string;
    scope: string;
    includeMcp: boolean;
    includeHooks: boolean;
    includeAgent: boolean;
}
export interface GitignoreOptions {
    yes?: boolean;
    interactive?: boolean;
}
export interface GitignoreResult {
    status: 'already-ignored' | 'updated' | 'needs-approval';
    path: string;
    entry: string;
}
export type StateLauncherResolution = {
    kind: 'resolved';
    agent: LauncherId;
} | {
    kind: 'ambiguous';
    agents: LauncherId[];
} | {
    kind: 'none';
};
export declare function stateFilePath(projectDir: string): string;
export declare function readState(projectDir: string): AzureFunctionsSkillsState | null;
export declare function writeState(projectDir: string, state: AzureFunctionsSkillsState): AzureFunctionsSkillsState;
export declare function recordInstallState(projectDir: string, options: RecordInstallStateOptions): AzureFunctionsSkillsState;
export declare function markSetupPrompted(projectDir: string, agent: LauncherId | null): AzureFunctionsSkillsState;
export declare function markSetupComplete(projectDir: string, completedBy: LauncherId | null): AzureFunctionsSkillsState;
export declare function getInstalledTargets(state: AzureFunctionsSkillsState): BuildTargetName[];
/**
 * Resolve the install mode for a set of agents from state.
 * Prefers per-agent `installMode`; falls back to top-level `install.mode`.
 * Returns `'mixed'` when selected agents have different modes.
 */
export declare function resolveInstallMode(state: AzureFunctionsSkillsState, agents: BuildTargetName[]): PluginInstallMode | 'mixed';
export declare function getInstalledLaunchers(state: AzureFunctionsSkillsState): LauncherId[];
export declare function resolveStateLauncher(state: AzureFunctionsSkillsState | null): StateLauncherResolution;
export declare function ensureStateIgnored(projectDir: string, options?: GitignoreOptions): GitignoreResult;
