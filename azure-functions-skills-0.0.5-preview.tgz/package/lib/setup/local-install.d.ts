import { type AzureFunctionsSkillsState, type GitignoreResult } from './state.js';
import { type PackageUpdateInfo } from './package-update.js';
import type { CliAgentName, SetupResult } from '../types.js';
import type { CommandRunner, PrerequisiteMode } from './prerequisites/types.js';
export type GitRepoResultStatus = 'skipped' | 'detected' | 'initialized' | 'not-initialized' | 'git-unavailable';
export interface GitRepoResult {
    readonly status: GitRepoResultStatus;
}
export interface LocalInstallOptions {
    readonly targetDir: string;
    readonly agents?: CliAgentName[];
    readonly dryRun?: boolean;
    readonly yes?: boolean;
    readonly prerequisites?: PrerequisiteMode;
    readonly scope?: string;
    readonly runner?: CommandRunner;
    readonly checkForUpdates?: boolean;
    readonly initializeGitForGhcp?: boolean;
    readonly approveStateGitignore?: () => Promise<boolean>;
    readonly approveGitInit?: () => Promise<boolean>;
}
export interface LocalInstallResult {
    readonly agents: CliAgentName[];
    readonly filesWritten: number;
    readonly plannedFiles: string[];
    readonly dryRun: boolean;
    readonly state: AzureFunctionsSkillsState | null;
    readonly gitignoreResult: GitignoreResult;
    readonly gitRepoResult: GitRepoResult;
    readonly packageUpdate: PackageUpdateInfo;
    readonly setup: SetupResult | null;
}
export declare function installLocalSkills(options: LocalInstallOptions): Promise<LocalInstallResult>;
