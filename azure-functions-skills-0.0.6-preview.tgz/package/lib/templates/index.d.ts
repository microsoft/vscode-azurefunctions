export declare const DEFAULT_TEMPLATE_MANIFEST_URL = "https://cdn.functions.azure.com/public/templates-manifest/manifest.json";
export type TemplateApplyMode = 'auto' | 'new' | 'add';
export interface TemplateListOptions {
    readonly manifestUrl?: string;
    readonly language?: string;
    readonly resource?: string;
    readonly iac?: string;
}
export interface TemplateApplyOptions {
    readonly manifestUrl?: string;
    readonly language?: string;
    readonly template: string;
    readonly runtimeVersion?: string;
    readonly mode?: TemplateApplyMode;
    readonly dryRun?: boolean;
    readonly force?: boolean;
}
export interface TemplateManifest {
    readonly version?: string;
    readonly runtimeVersions?: Record<string, TemplateRuntimeVersions>;
    readonly languages?: readonly string[];
    readonly templates: readonly FunctionTemplate[];
}
export interface TemplateRuntimeVersions {
    readonly supported?: readonly string[];
    readonly preview?: readonly string[];
    readonly frameworkSupported?: readonly string[];
    readonly default?: string;
}
export interface FunctionTemplate {
    readonly id: string;
    readonly displayName: string;
    readonly shortDescription: string;
    readonly longDescription?: string;
    readonly language: string;
    readonly bindingType?: string;
    readonly resource?: string;
    readonly iac?: string;
    readonly priority?: number;
    readonly categories?: readonly string[];
    readonly tags?: readonly string[];
    readonly author?: string;
    readonly repositoryUrl: string;
    readonly folderPath: string;
    readonly gitRef?: string;
    readonly whatsIncluded?: readonly string[];
}
export interface TemplateListResult {
    readonly manifestUrl: string;
    readonly templates: readonly FunctionTemplate[];
}
export interface TemplateApplyResult {
    readonly template: FunctionTemplate;
    readonly mode: Exclude<TemplateApplyMode, 'auto'>;
    readonly dryRun: boolean;
    readonly filesWritten: readonly string[];
    readonly skippedFiles: readonly string[];
    readonly plannedFiles: readonly string[];
}
export declare function listFunctionTemplates(options?: TemplateListOptions): Promise<TemplateListResult>;
export declare function applyFunctionTemplate(targetDir: string, options: TemplateApplyOptions): Promise<TemplateApplyResult>;
