/**
 * Version rules for Tier 1 checks — hardcoded fallback.
 * Used only when the Stacks API (stacks.ts) is unreachable and no cache exists.
 * Keep in sync with https://functions-next.azure.com/stacks/functionAppStacks/?api-version=2023-01-01
 * Last synced: 2026-05-26
 */
export declare const SUPPORTED_RUNTIME_VERSIONS: string[];
export declare const RECOMMENDED_EXTENSION_BUNDLE: {
    id: string;
    minVersion: string;
    maxVersion: string;
};
export declare const SUPPORTED_NODE_VERSIONS: number[];
export declare const SUPPORTED_PYTHON_VERSIONS: string[];
export declare const SUPPORTED_DOTNET_VERSIONS: string[];
/**
 * Minimum Go toolchain required by the Azure Functions Go worker.
 * Go support is in preview; the worker module declares `go 1.24.0`.
 */
export declare const MIN_GO_VERSION = "1.24";
/** Go module path of the Azure Functions Go worker (lower-case; module paths are case-sensitive). */
export declare const GO_WORKER_MODULE = "github.com/azure/azure-functions-golang-worker";
/**
 * The only correct `FUNCTIONS_WORKER_RUNTIME` value for Go apps.
 * Go runs on the host's `native` worker. `go` and `golang` are misconfigurations.
 */
export declare const GO_WORKER_RUNTIME = "native";
/** Settings that are deprecated and should be replaced. */
export declare const DEPRECATED_SETTINGS: Record<string, string>;
