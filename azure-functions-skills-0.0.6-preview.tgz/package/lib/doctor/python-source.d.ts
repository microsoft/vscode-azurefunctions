import { type PythonFileReader } from './python-files.js';
import type { FunctionInfo } from './types.js';
export interface PythonSourceInventory {
    hasV2Application: boolean;
    functions: FunctionInfo[];
}
export declare function discoverPythonV2Functions(dir: string, readFile?: PythonFileReader): PythonSourceInventory;
