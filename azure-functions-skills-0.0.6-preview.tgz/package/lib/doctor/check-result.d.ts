import type { DoctorCheck, DoctorCheckResult } from './types.js';
export declare function makeCheckResult(check: DoctorCheck, overrides: Partial<DoctorCheckResult> & {
    status: DoctorCheckResult['status'];
    title: string;
    message: string;
}): DoctorCheckResult;
