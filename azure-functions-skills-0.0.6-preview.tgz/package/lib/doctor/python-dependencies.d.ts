import { type PythonFileReader } from './python-files.js';
export type PythonManifestKind = 'requirements' | 'pyproject' | 'none';
export interface PythonDependency {
    name: string;
    specifier: string;
    pinned: boolean;
    hashes: string[];
    directUrl: boolean;
    sourceFile: string;
    line: number;
}
export interface PythonDependencyManifest {
    kind: PythonManifestKind;
    files: string[];
    dependencies: PythonDependency[];
    warnings: string[];
}
export declare function loadPythonDependencies(dir: string): PythonDependencyManifest;
export declare function hasExternalPythonImports(dir: string, readFile?: PythonFileReader): boolean;
