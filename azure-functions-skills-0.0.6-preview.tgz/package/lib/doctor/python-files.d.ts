export type PythonFileReader = (path: string) => string | null;
export declare function readPythonFile(path: string): string | null;
