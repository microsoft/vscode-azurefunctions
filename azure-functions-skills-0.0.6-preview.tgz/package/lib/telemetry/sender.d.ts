export declare const BUNDLED_SKILL_NAMES: Set<string>;
export type TelemetryEventType = 'skill_invocation' | 'tool_invocation' | 'reference_file_read';
export interface TelemetryEvent {
    readonly timestamp: string;
    readonly eventType: TelemetryEventType;
    readonly clientName: string;
    readonly pluginName: 'azure-functions-skills';
    readonly sessionId?: string;
    readonly skillName?: string;
    readonly toolName?: string;
    readonly fileReference?: string;
}
export type TelemetrySendStatus = 'sent' | 'disabled' | 'not-configured';
export interface TelemetrySendResult {
    readonly status: TelemetrySendStatus;
}
export interface ApplicationInsightsClient {
    trackEvent(event: {
        readonly name: string;
        readonly properties: Readonly<Record<string, string>>;
    }): void;
    flush(options: {
        readonly callback: (response?: string) => void;
    }): void;
}
interface TelemetryEnvironment {
    readonly AZURE_FUNCTIONS_SKILLS_COLLECT_TELEMETRY?: string;
    readonly AZURE_MCP_COLLECT_TELEMETRY?: string;
}
export interface TelemetryDependencies {
    readonly connectionString: string;
    readonly createClient: (connectionString: string) => ApplicationInsightsClient;
    readonly environment: TelemetryEnvironment;
    readonly timeoutMs: number;
}
export declare function parseTelemetryEvent(value: unknown): TelemetryEvent;
export declare function sendTelemetryEventWithDependencies(event: TelemetryEvent, dependencies: TelemetryDependencies): Promise<TelemetrySendResult>;
export declare function sendTelemetryEvent(event: TelemetryEvent): Promise<TelemetrySendResult>;
export {};
