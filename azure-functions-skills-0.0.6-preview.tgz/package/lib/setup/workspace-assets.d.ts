import type { CliAgentName } from '../types.js';
export declare function telemetryConfigPath(root: string, agent: CliAgentName): string;
export declare function resolveTelemetryEnabled(targetDir: string, explicit: boolean | undefined): boolean | undefined;
export declare function setTelemetryEnabled(configPath: string, enabled: boolean): void;
export declare function prepareWorkspaceFile(relativePath: string, existingPath: string, generatedPath: string): void;
