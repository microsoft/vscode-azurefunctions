import { type CommandRunner, type PackageUpdateInfo } from './package-update.js';
import type { CliAgentName } from '../types.js';
export interface LocalInstallOptions {
    readonly targetDir: string;
    readonly agents?: CliAgentName[];
    readonly dryRun?: boolean;
    readonly telemetryEnabled?: boolean;
    readonly checkForUpdates?: boolean;
    readonly runner?: CommandRunner;
}
export interface LocalInstallResult {
    readonly agents: CliAgentName[];
    readonly filesWritten: number;
    readonly plannedFiles: string[];
    readonly dryRun: boolean;
    readonly packageUpdate: PackageUpdateInfo;
}
export declare function detectAgents(): Promise<CliAgentName[]>;
export declare function installLocalSkills(options: LocalInstallOptions): Promise<LocalInstallResult>;
export { checkPackageUpdate, type CommandRunner, type PackageUpdateInfo, type PackageUpdateOptions, type PackageUpdateStatus, } from './package-update.js';
