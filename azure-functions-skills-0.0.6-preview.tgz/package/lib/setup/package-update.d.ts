export interface CommandResult {
    readonly exitCode: number;
    readonly stdout: string;
    readonly stderr: string;
}
export interface CommandRunner {
    (command: string, args: string[], options?: {
        cwd?: string;
    }): Promise<CommandResult>;
}
export type PackageUpdateStatus = 'current' | 'update-available' | 'check-failed' | 'disabled';
export interface PackageUpdateInfo {
    readonly status: PackageUpdateStatus;
    readonly packageName: string;
    readonly currentVersion: string;
    readonly latestVersion?: string;
    readonly command?: string;
    readonly message: string;
}
export interface PackageUpdateOptions {
    readonly packageName?: string;
    readonly currentVersion?: string;
    readonly runner?: CommandRunner;
    readonly enabled?: boolean;
}
export declare function checkPackageUpdate(options?: PackageUpdateOptions): Promise<PackageUpdateInfo>;
